#!/usr/bin/env bash
set -euo pipefail

USER="hwiwonlee"
API_URL="https://hub.docker.com/v2/repositories/${USER}"
PAGE_SIZE=100
PAGE=1

BASE_DIR="$(pwd)"
ARTIFACT_DIR="${BASE_DIR}/artifact"
OUTPUT_FILE="${ARTIFACT_DIR}/repos.json"
TMP_FILE="$(mktemp)"

mkdir -p "$ARTIFACT_DIR"

echo "📦 Fetching all repositories for user '${USER}' ..."
echo "(Saving to ${OUTPUT_FILE})"
echo

# Fetch all pages and collect repo names
while true; do
  RESP=$(curl -s "${API_URL}/?page=${PAGE}&page_size=${PAGE_SIZE}")
  echo "${RESP}" | jq -r '.results[]?.name' >> "$TMP_FILE"
  NEXT=$(echo "${RESP}" | jq -r '.next')
  if [[ "${NEXT}" == "null" || -z "${NEXT}" ]]; then
    break
  fi
  PAGE=$((PAGE+1))
done

# Convert newline-separated names to JSON list
jq -R -s 'split("\n")[:-1]' "$TMP_FILE" > "$OUTPUT_FILE"
rm -f "$TMP_FILE"

echo
echo "✅ Done. Saved $(jq 'length' "$OUTPUT_FILE") repositories to ${OUTPUT_FILE}"
