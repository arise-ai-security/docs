#!/usr/bin/env bash
set -euo pipefail

# ===== Configuration =====
TYPE="${1:-OSV}"
LANGS="${2:-C,C++}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
ARTIFACT_DIR="${BASE_DIR}/artifact"
INPUT_DIR="${ARTIFACT_DIR}/input"
SEED_DIR="${ARTIFACT_DIR}/1-seed"
REPORT_DIR="${ARTIFACT_DIR}/2-report"
PROJECT_DIR="${ARTIFACT_DIR}/3-project"

# ===== Logging =====
log() { echo -e "\033[1;34m[$(date '+%H:%M:%S')] $*\033[0m"; }

# ===== Generate File Name Slug =====
to_slug() {
  printf '%s' "$1" \
    | tr '[:upper:]' '[:lower:]' \
    | sed -e 's/c++/cpp/g' \
    | tr ',' '-' \
    | tr -d ' ' \
    | sed -E 's/-+/-/g; s/^-+//; s/-+$//'
}
type_slug="$(to_slug "$TYPE")"
langs_slug="$(to_slug "$LANGS")"
base_name="${type_slug}-${langs_slug}-data.jsonl"

seed_out="${SEED_DIR}/${base_name}"
report_out="${REPORT_DIR}/${base_name}"
project_out="${PROJECT_DIR}/${base_name}"

# ===== Main Pipeline =====
log "▶ Running seed stage..."
python -m secb.preprocessor.seed \
  --input-dir "${INPUT_DIR}" \
  --output-file "${seed_out}"

log "▶ Running report stage..."
python -m secb.preprocessor.report \
  --input-file "${seed_out}" \
  --output-file "${report_out}" \
  --type "${TYPE}" \
  --lang "${LANGS}" \
  --oss-fuzz

log "▶ Running project stage..."
python -m secb.preprocessor.project \
  --input-file "${report_out}" \
  --output-file "${project_out}"

# ===== Done =====
log "✅ Pipeline completed."
echo "  Seed:    ${seed_out}"
echo "  Report:  ${report_out}"
echo "  Project: ${project_out}"
