#!/usr/bin/env bash
set -euo pipefail

# ===== Configuration =====
TYPE="OSV"
LANGS="C,C++"
FILTER_DOCKER_HUB="true"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ===== Parse Arguments =====
while [[ $# -gt 0 ]]; do
  case "$1" in
    --filter-docker-hub)
      FILTER_DOCKER_HUB="true"
      shift
      ;;
    *)
      echo "Unknown option: $1"
      echo "Usage: $0 [--filter-docker-hub]"
      exit 1
      ;;
  esac
done

# ===== Main Execution =====
echo "==============================================="
echo "  SEC-bench Data Collection Pipeline"
echo "==============================================="
echo ""

# Step 1: Setup directories
bash "${SCRIPT_DIR}/setup_dirs.sh"
echo ""

# Step 2: Download OSV dataset (commented out by default)
bash "${SCRIPT_DIR}/download_osv.sh"
echo ""

# Step 2.5: Filter input files based on Docker Hub repos (optional)
if [[ "$FILTER_DOCKER_HUB" == "true" ]]; then
  bash "${SCRIPT_DIR}/cleanup_input.sh"
  echo ""
fi

# Step 3: Run pipeline
bash "${SCRIPT_DIR}/run_pipeline.sh" "${TYPE}" "${LANGS}"

echo ""
echo "==============================================="
echo "  All tasks completed successfully!"
echo "==============================================="
