#!/usr/bin/env bash
set -euo pipefail

# ===== Configuration =====
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
ARTIFACT_DIR="${BASE_DIR}/artifact"
REPOS_JSON="${ARTIFACT_DIR}/repos.json"
INPUT_DIR="${ARTIFACT_DIR}/input"

# ===== Logging =====
log() { echo -e "\033[1;34m[$(date '+%H:%M:%S')] $*\033[0m"; }
warn() { echo -e "\033[1;33m[$(date '+%H:%M:%S')] $*\033[0m"; }
error() { echo -e "\033[1;31m[$(date '+%H:%M:%S')] $*\033[0m"; }

# ===== Validate paths =====
if [[ ! -f "$REPOS_JSON" ]]; then
  error "Error: ${REPOS_JSON} does not exist."
  exit 1
fi

if [[ ! -d "$INPUT_DIR" ]]; then
  error "Error: ${INPUT_DIR} does not exist."
  exit 1
fi

# ===== Check for jq =====
if ! command -v jq &> /dev/null; then
  error "Error: jq is not installed. Please install it first (brew install jq)."
  exit 1
fi

# ===== Read repos.json and extract valid names =====
log "📖 Reading ${REPOS_JSON} ..."

# Extract last segment after '.' from each item, convert to uppercase
valid_names=$(jq -r '.[]' "$REPOS_JSON" | awk -F'.' '{print toupper($NF)}' | sort -u)
valid_count=$(echo "$valid_names" | wc -l | tr -d ' ')

log "✅ Extracted ${valid_count} unique names."
log "   Example: $(echo "$valid_names" | head -5 | tr '\n' ' ')"

# Create a temporary file with valid names
temp_valid_names=$(mktemp)
echo "$valid_names" > "$temp_valid_names"

# ===== Find items to remove =====
log ""
log "📁 Scanning ${INPUT_DIR} ..."

to_remove=()
total_items=0

while IFS= read -r -d '' item; do
  # Skip .DS_Store files
  [[ "$(basename "$item")" == ".DS_Store" ]] && continue

  total_items=$((total_items + 1))

  # Get name without extension
  name=$(basename "$item")
  name_without_ext="${name%.*}"

  # Convert to uppercase for comparison
  name_upper=$(echo "$name_without_ext" | tr '[:lower:]' '[:upper:]')

  # Check if name exists in valid_names
  if ! grep -Fxq "$name_upper" "$temp_valid_names"; then
    to_remove+=("$item")
  fi
done < <(find "$INPUT_DIR" -mindepth 1 -maxdepth 1 -print0)

rm -f "$temp_valid_names"

log "Found ${total_items} items in ${INPUT_DIR}"

# ===== Show removal preview =====
if [[ ${#to_remove[@]} -eq 0 ]]; then
  log ""
  log "✨ No items to remove. All files/directories are valid."
  exit 0
fi

warn ""
warn "⚠️  The following ${#to_remove[@]} items will be removed:"

count=0
for item in "${to_remove[@]}"; do
  if [[ $count -lt 20 ]]; then
    item_type="file"
    [[ -d "$item" ]] && item_type="directory"
    warn "   - $(basename "$item") ($item_type)"
  fi
  count=$((count + 1))
done

if [[ ${#to_remove[@]} -gt 20 ]]; then
  warn "   ... and $((${#to_remove[@]} - 20)) more"
fi

# ===== Ask for confirmation =====
echo ""
read -p "Proceed with deletion? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
  error "❌ Cancelled."
  exit 0
fi

# ===== Execute removal =====
log ""
log "🗑️  Removing..."

removed_count=0
failed_count=0

for item in "${to_remove[@]}"; do
  if rm -rf "$item" 2>/dev/null; then
    removed_count=$((removed_count + 1))
    if [[ $removed_count -le 10 ]] || [[ $((removed_count % 100)) -eq 0 ]]; then
      log "   ✓ Removed: $(basename "$item")"
    fi
  else
    error "   ✗ Failed to remove $(basename "$item")"
    failed_count=$((failed_count + 1))
  fi
done

log ""
log "✅ Done! Removed ${removed_count} items."

if [[ $failed_count -gt 0 ]]; then
  warn "⚠️  ${failed_count} items failed to remove."
fi
