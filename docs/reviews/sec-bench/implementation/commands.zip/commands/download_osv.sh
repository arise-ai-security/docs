#!/usr/bin/env bash
set -euo pipefail

# ===== Configuration =====
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
ARTIFACT_DIR="${BASE_DIR}/artifact"
INPUT_DIR="${ARTIFACT_DIR}/input"

# ===== Logging =====
log() { echo -e "\033[1;34m[$(date '+%H:%M:%S')] $*\033[0m"; }

# ===== Download and Extract OSV Dataset =====
if [[ -n "$(find "${INPUT_DIR}" -type f -not -name '.DS_Store' -print -quit 2>/dev/null)" ]]; then
  log "ℹ️  Existing files detected in ${INPUT_DIR} — skipping dataset download."
  log "   To download fresh data, please empty the input directory first."
else
  log "✅ Input directory is empty — proceeding with OSV dataset download..."
  log "▶ Downloading OSV dataset..."
  curl -L -o "${INPUT_DIR}/all.zip" "https://storage.googleapis.com/osv-vulnerabilities/all.zip"

  log "▶ Unzipping dataset into ${INPUT_DIR}..."
  unzip -q -o "${INPUT_DIR}/all.zip" -d "${INPUT_DIR}"
  rm -f "${INPUT_DIR}/all.zip"

  log "✅ OSV dataset downloaded and extracted to ${INPUT_DIR}"
fi
