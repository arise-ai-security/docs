#!/usr/bin/env bash
set -euo pipefail

# ===== Configuration =====
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
ARTIFACT_DIR="${BASE_DIR}/artifact"
INPUT_DIR="${ARTIFACT_DIR}/input"
SEED_DIR="${ARTIFACT_DIR}/1-seed"
REPORT_DIR="${ARTIFACT_DIR}/2-report"
PROJECT_DIR="${ARTIFACT_DIR}/3-project"

# ===== Logging =====
log() { echo -e "\033[1;34m[$(date '+%H:%M:%S')] $*\033[0m"; }

# ===== Directory Setup =====
log "▶ Creating directories..."
mkdir -p "$INPUT_DIR" "$SEED_DIR" "$REPORT_DIR" "$PROJECT_DIR"

log "✅ Directories created:"
echo "  Input:   ${INPUT_DIR}"
echo "  Seed:    ${SEED_DIR}"
echo "  Report:  ${REPORT_DIR}"
echo "  Project: ${PROJECT_DIR}"
